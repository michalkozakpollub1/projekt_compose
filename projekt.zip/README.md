Apache z portem 6666 odkrytym na swiat
W pliku env zmiana wersji PHP, MYSQL, Apache, 
ustawien dostepu do bazy danych, folderu z plikiem index.html.
Uruchamianie: docker-compose up -d
Zatrzymywanie z usunieciem wszystkiego: docker-compose down --volumes --rmi all
